const { createPool } = require('mysql');
const mysql = createPool({
    host: 'localhost',
    user: 'heyd',
    port: 3306,
    password: 'sagar4343',
    database: 'heyd',
    multipleStatements: true
})

module.exports = mysql;