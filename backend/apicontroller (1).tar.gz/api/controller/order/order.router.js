const express = require('express')
const router = express.Router()
const multer = require('multer')

const auth = require('../../middleware/auth')
const { createOrders, getAllOrders, getOrdersById, updateOrders, deleteOrders } = require('./order.controller')

const upload = multer()

router.post('/', upload.none(),createOrders)

router.get('/', getAllOrders)

router.get('/:id', getOrdersById)

router.patch('/:id', upload.none(), updateOrders)

router.delete('/:id', deleteOrders)

module.exports = router